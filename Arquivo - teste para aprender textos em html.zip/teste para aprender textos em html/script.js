// Selecionar elementos do DOM
const productList = document.getElementById('product-list');
const productForm = document.getElementById('product-form');

// Adicionar evento no formulário
productForm.addEventListener('submit', (e) => {
  e.preventDefault();

  // Obter valores dos inputs
  const name = document.getElementById('name').value;
  const image = document.getElementById('image').value;
  const price = document.getElementById('price').value;
  const link = document.getElementById('link').value;

  // Criar um novo produto
  const product = document.createElement('div');
  product.classList.add('product');
  product.innerHTML = `
    <img src="${image}" alt="${name}">
    <h3>${name}</h3>
    <p>R$ ${parseFloat(price).toFixed(2)}</p>
    <a href="${link}" target="_blank">Comprar</a>
  `;

  // Adicionar o produto à lista
  productList.appendChild(product);

  // Limpar o formulário
  productForm.reset();
});